package org.cloudbus.cloudsim.examples;

/*
 * Title:        CloudSim Toolkit
 * Description:  CloudSim (Cloud Simulation) Toolkit for Modeling and Simulation
 *               of Clouds
 * Licence:      GPL - http://www.gnu.org/copyleft/gpl.html
 *
 * Copyright (c) 2009, The University of Melbourne, Australia
 */

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

/**
 * Exemplo simple que mostra como criar um Data Center com um host e executando uma tarefa/aplicação (Cloudlet).
 */
public class CloudSimExample1 {
	/** Lista de cloudlet. */
	private static List<Cloudlet> cloudletList;
	/** Lista de VMs. */
	private static List<Vm> vmlist;

	/**
	 * Creates main() to run this example.
	 *
	 * @param args the args
	 */
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Log.printLine("Starting CloudSimExample1...");

		try {
			// 1º Passo: Inicialize o pacote CloudSim . 
			int num_user = 1; // Numnero de usuário na nuvem
			Calendar calendar = Calendar.getInstance(); // Calendariod e atividade - data corrente.
 			boolean trace_flag = false; // trace events

			CloudSim.init(num_user, calendar, trace_flag);

			// 2º Passo: Criar o Data Center
			// O Data Center concentra os recursos disposíveis pela Nuvem. 
                        
			Datacenter datacenter0 = createDatacenter("Datacenter_0");

			// 3º Passo:: Criar o painel de controle da Nuvem (Broker).
			DatacenterBroker broker = createBroker();
			int brokerId = broker.getId();

			// 4º Passo: Criar uma maquina virtual
			vmlist = new ArrayList<Vm>();

			// Descreição da VM 
			int vmid = 0;   // identificador ID
			int mips = 1000;    // capacidade de processamento (Milhores de instrução por segundo. 
			long size = 10000; // tamanho da imagemsize (MB)
			int ram = 512; // tamanho da memória principal RAM (MB)
			long bw = 1000; // banda de transmissão
			int pesNumber = 1; // número de cpus
			String vmm = "Xen"; // Nome da VM

			// Criar VM
			Vm vm = new Vm(vmid, brokerId, mips, pesNumber, ram, bw, size, vmm, new CloudletSchedulerTimeShared());

			// adicionar a VM a lista 
			vmlist.add(vm);

			// Submeter a lista de VMs ao broker
			broker.submitVmList(vmlist);

			// 5º Passo : Criar a tarefa/aplicação - Cloudlet
			cloudletList = new ArrayList<Cloudlet>();

			// Propriedade da Cloudlet 
			int id = 0;
			long length = 400000; // comprimento inicial da aplicação
			long fileSize = 300; // tamanho do arquivo
			long outputSize = 300; // tamanho para envio
			UtilizationModel utilizationModel = new UtilizationModelFull();

			Cloudlet cloudlet = 
                                new Cloudlet(id, length, pesNumber, fileSize, 
                                        outputSize, utilizationModel, utilizationModel, 
                                        utilizationModel);
			cloudlet.setUserId(brokerId);
			cloudlet.setVmId(vmid);

			// adicina a liata de cloudlets
			cloudletList.add(cloudlet);

			// Submete a lista ao broker
			broker.submitCloudletList(cloudletList);

			// 6º Passo: Inicia a simulação
			CloudSim.startSimulation();

			CloudSim.stopSimulation();

			//Etapa final: Apresenta os resultados de simulação
			List<Cloudlet> newList = broker.getCloudletReceivedList();
			printCloudletList(newList);

			Log.printLine("CloudSimExample1 finished!");
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("Unwanted errors happen");
		}
	}

	/**
	 * Creates the datacenter.
	 *
	 * @param name the name
	 *
	 * @return the datacenter
	 */
	private static Datacenter createDatacenter(String name) {

		// Here are the steps needed to create a PowerDatacenter:
		// 1. Criar uma lista de hosts - maquinas físicas
		List<Host> hostList = new ArrayList<Host>();

		// 2. Uma host contem um ou mais nucleos - CPUs/Cores.
		List<Pe> peList = new ArrayList<Pe>();

		int mips = 1000; // capacidade de processamento (milhões de instruções por segundo)

		// 3. Cria um Pe e adiciona a lista.
		peList.add(new Pe(0, new PeProvisionerSimple(mips))); // need to store Pe id and MIPS Rating

		// 4. Cria o Host com seu ID e a lista de PEs
		// por maquina
		int hostId = 0;
		int ram = 2048; // Memoria do host (MB)
		long storage = 1000000; // capacidade de armazenamento
		int bw = 10000; // capacidade de transmissão - banda

		hostList.add(
			new Host(
				hostId,
				new RamProvisionerSimple(ram),
				new BwProvisionerSimple(bw),
				storage,
				peList,
				new VmSchedulerTimeShared(peList)
			)
		); // Esta é a nossa maquina

		// 5. Criar as informações do Data Center
		// propriedades, arquiteturas, SO, lista de maquinas
		// politica de alocação: por tempo ou por espaço compartilhado, local
		// e preços  (G$/Pe unidade de tempo).
		String arch = "x86"; // Arquitetura
		String os = "Linux"; // Sistema operacional
		String vmm = "Xen";
		double time_zone = 10.0; // localização
		double cost = 3.0; // custo de processamento
		double costPerMem = 0.05; // custo de memória
		double costPerStorage = 0.001; // custo de armazenamento
										// resource
		double costPerBw = 0.0; // custo de banda
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are not adding SAN
							// devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
				arch, os, vmm, hostList, time_zone, cost, costPerMem,
				costPerStorage, costPerBw);

		// 6. Instancia do Data Center.
		Datacenter datacenter = null;
		try {
			datacenter = new Datacenter(name, characteristics, new VmAllocationPolicySimple(hostList), storageList, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}

	// We strongly encourage users to develop their own broker policies, to
	// submit vms and cloudlets according
	// to the specific rules of the simulated scenario
	/**
	 * Creates the broker.
	 *
	 * @return the datacenter broker
	 */
	private static DatacenterBroker createBroker() {
		DatacenterBroker broker = null;
		try {
			broker = new DatacenterBroker("Broker");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}

	/**
	 * Prints the Cloudlet objects.
	 *
	 * @param list list of Cloudlets
	 */
	private static void printCloudletList(List<Cloudlet> list) {
		int size = list.size();
		Cloudlet cloudlet;

		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent + "STATUS" + indent
				+ "Data center ID" + indent + "VM ID" + indent + "Time" + indent
				+ "Start Time" + indent + "Finish Time");

		DecimalFormat dft = new DecimalFormat("###.##");
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
				Log.print("SUCCESS");

				Log.printLine(indent + indent + cloudlet.getResourceId()
						+ indent + indent + indent + cloudlet.getVmId()
						+ indent + indent
						+ dft.format(cloudlet.getActualCPUTime()) + indent
						+ indent + dft.format(cloudlet.getExecStartTime())
						+ indent + indent
						+ dft.format(cloudlet.getFinishTime()));
			}
		}
	}
}